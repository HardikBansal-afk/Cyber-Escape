using UnityEngine;

public class DoorTrigger : MonoBehaviour
{
    public GameObject door;
    private bool isOpen = false;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !isOpen)
        {
            door.transform.Rotate(0, 90, 0);
            isOpen = true;
        }
    }
}
